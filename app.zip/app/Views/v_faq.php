<?= $this->extend('layout')?>
<?= $this->section('content')?>
ini page FAQ
<?= $this->endSection()?>